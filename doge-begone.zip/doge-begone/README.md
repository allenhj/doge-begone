# Doge Begone

Reverts the logo on Twitter.com to the original Twitter bird.
